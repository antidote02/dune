#version 400 compatibility
#define WORLD_NETHER
#define BLOOM_TILE_INDEX 4
#define vsh
#include "/program/c14_c18_bloom_upsample.vsh"

