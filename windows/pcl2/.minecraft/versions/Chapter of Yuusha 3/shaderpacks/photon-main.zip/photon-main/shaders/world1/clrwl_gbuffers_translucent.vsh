#version 400 compatibility
#define WORLD_END
#define PROGRAM_GBUFFERS_WATER
#define COLORWHEEL
#define vsh
#include "/program/gbuffers_all_translucent.vsh"
